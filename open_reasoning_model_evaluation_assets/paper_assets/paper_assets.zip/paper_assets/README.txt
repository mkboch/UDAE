paper_assets/
├── figures/
│   ├── weighted_ranking_bar.png
│   ├── heatmap_accuracy_cot.png
│   ├── heatmap_accuracy_few_shot_cot.png
│   ├── heatmap_accuracy_zero_shot.png
│   ├── weighted_vs_latency_scatter.png
│   ├── weighted_vs_vram_scatter.png
│   └── prompt_sensitivity_grouped_bar.png
└── tables/
    ├── table_weighted_ranking.tex
    ├── table_best_per_dataset.tex
    ├── table_top10_deployment.tex
    └── table_full_condition_matrix.tex

Source files:
- workshop_unified238_v1_final/aggregated_workshop_unified238_v1.csv
- workshop_unified238_v1_final/weighted_summary_workshop_unified238_v1.csv
